# mxonline_resources
mxonline的课程资源

慕课网课程地址 http://coding.imooc.com/class/78.html

最新的源码管理我通过github私人仓库管理，已经购买的用户到这里申请加入： http://apply.projectsedu.com/ ， 后期我会持续更新
